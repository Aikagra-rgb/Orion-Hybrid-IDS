/**
 * Orion IDS Dashboard — Main Application
 * Component loader and module orchestrator.
 */

import { initSidebar } from './modules/sidebar.js';
import { initParallax } from './modules/parallax.js';
import { initSearch } from './modules/search.js';
import { navigateTo } from './modules/router.js';
import { initStatusBar } from './modules/statusbar.js';
import { initNotifications } from './modules/notifications.js';

/**
 * Load an HTML partial into a container element.
 */
async function loadComponent(url, target, mode = 'replace') {
  const el = typeof target === 'string' ? document.querySelector(target) : target;
  if (!el) {
    console.warn(`[Orion] Target not found for component: ${url}`);
    return;
  }

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();

    if (mode === 'append') {
      el.insertAdjacentHTML('beforeend', html);
    } else {
      el.innerHTML = html;
    }
  } catch (err) {
    console.error(`[Orion] Failed to load component ${url}:`, err);
  }
}

/**
 * Bootstrap — load shell components, then navigate to dashboard.
 */
async function bootstrap() {
  // Load top bar and sidebar (shell components)
  await loadComponent('components/topbar.html', '#topbar-slot');
  await loadComponent('components/sidebar.html', '#sidebar-slot');
  await loadComponent('components/statusbar.html', '#statusbar-slot');
  await loadComponent('components/notifications.html', '#notif-slot');

  // Init shell-level modules (these persist across page navigations)
  initSidebar();
  initParallax();
  initSearch();
  initStatusBar();
  initNotifications();

  // Navigate to default page (dashboard)
  await navigateTo('dashboard');
}

// Start
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootstrap);
} else {
  bootstrap();
}
