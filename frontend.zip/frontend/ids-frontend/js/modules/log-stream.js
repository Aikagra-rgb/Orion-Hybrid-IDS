/**
 * Log Stream Module
 * Terminal-style scrolling log feed with auto-generation and pause/clear controls.
 */

const LOG_SOURCES = ['fw.core', 'ids.engine', 'net.mon', 'auth.sys', 'dns.proxy', 'http.guard', 'pkt.insp'];

const LOG_TEMPLATES = {
  info: [
    'Connection established from {ip}:{port}',
    'Packet inspection completed — {count} packets analyzed',
    'DNS query resolved: {domain} → {ip}',
    'TLS handshake completed with {ip}',
    'Health check passed for node {node}',
    'Rule #{rule} matched — action: allow',
    'Session {sid} authenticated successfully',
  ],
  warn: [
    'Unusual traffic pattern detected from {ip}',
    'Rate limit threshold approaching: {count}/min',
    'Certificate expiry warning for {domain}',
    'Connection timeout from {ip}:{port}',
    'Retransmission rate elevated on interface eth{iface}',
    'Geolocation anomaly: {ip} from unexpected region',
  ],
  error: [
    'Blocked malicious payload from {ip}',
    'Intrusion attempt detected — signature #{rule}',
    'Failed authentication from {ip} (attempt {count})',
    'Suspicious port scan from {ip} — {count} ports',
    'Malware signature match: {domain}',
    'Rule #{rule} triggered — action: block + alert',
  ],
  debug: [
    'Packet buffer: {count} entries queued',
    'GC cycle completed in {ms}ms',
    'Worker thread #{rule} idle',
    'Cache hit ratio: {pct}%',
  ],
};

function randomIP() {
  return `${Math.floor(Math.random()*223)+1}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*254)+1}`;
}

function randomDomain() {
  const names = ['cdn.example', 'api.service', 'auth.internal', 'db.cluster', 'mail.corp', 'vpn.edge', 'proxy.sec'];
  const tlds = ['.com', '.io', '.net', '.internal'];
  return names[Math.floor(Math.random() * names.length)] + tlds[Math.floor(Math.random() * tlds.length)];
}

function fillTemplate(tmpl) {
  return tmpl
    .replace('{ip}', randomIP())
    .replace('{port}', String(1024 + Math.floor(Math.random() * 64000)))
    .replace('{count}', String(Math.floor(Math.random() * 500) + 1))
    .replace('{domain}', randomDomain())
    .replace('{node}', `n-${Math.floor(Math.random() * 12) + 1}`)
    .replace('{rule}', String(Math.floor(Math.random() * 9000) + 1000))
    .replace('{sid}', Math.random().toString(36).substring(2, 10))
    .replace('{iface}', String(Math.floor(Math.random() * 4)))
    .replace('{ms}', String(Math.floor(Math.random() * 50) + 5))
    .replace('{pct}', String(Math.floor(Math.random() * 30) + 70));
}

function generateLogLine() {
  const now = new Date();
  const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const rand = Math.random();
  let level;
  if (rand < 0.45) level = 'info';
  else if (rand < 0.70) level = 'warn';
  else if (rand < 0.88) level = 'error';
  else level = 'debug';

  const templates = LOG_TEMPLATES[level];
  const msg = fillTemplate(templates[Math.floor(Math.random() * templates.length)]);
  const source = LOG_SOURCES[Math.floor(Math.random() * LOG_SOURCES.length)];

  return { time, level, source, msg };
}

export function initLogStream() {
  const container = document.getElementById('logStream');
  const pauseBtn = document.getElementById('logPauseBtn');
  const clearBtn = document.getElementById('logClearBtn');
  if (!container) return;

  let paused = false;
  let intervalId;
  const MAX_LINES = 120;

  function addLine() {
    if (paused) return;

    const log = generateLogLine();
    const div = document.createElement('div');
    div.className = 'log-entry';
    div.innerHTML = `
      <span class="log-time">${log.time}</span>
      <span class="log-level log-level--${log.level}">${log.level.toUpperCase().padEnd(5)}</span>
      <span class="log-source">[${log.source}]</span>
      <span class="log-msg">${log.msg}</span>
    `;
    container.appendChild(div);

    // Trim old lines
    while (container.children.length > MAX_LINES) {
      container.removeChild(container.firstChild);
    }

    // Auto-scroll to bottom
    container.scrollTop = container.scrollHeight;
  }

  // Seed initial lines
  for (let i = 0; i < 15; i++) addLine();

  // Stream new lines
  intervalId = setInterval(addLine, 800 + Math.random() * 600);

  // Pause/Resume
  if (pauseBtn) {
    pauseBtn.addEventListener('click', () => {
      paused = !paused;
      pauseBtn.innerHTML = paused
        ? '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M4 2l8 5-8 5V2z" fill="currentColor"/></svg>'
        : '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="3" y="2" width="3" height="10" rx="0.5" fill="currentColor"/><rect x="8" y="2" width="3" height="10" rx="0.5" fill="currentColor"/></svg>';
    });
  }

  // Clear
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      container.innerHTML = '';
    });
  }

  return () => clearInterval(intervalId);
}
