/**
 * Alerts Module
 * Fetches live alerts from ORION backend, renders rows, and handles severity filtering.
 */

// We store the live data here so filtering buttons work instantly without re-fetching
let liveAlertsData = [];

// Fetch data from the FastAPI bridge
async function fetchLiveAlerts() {
  try {
    const response = await fetch('/api/alerts');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    liveAlertsData = await response.json();
    
    // Check which filter button is currently active
    const activeFilterBtn = document.querySelector('.filter-btn--active');
    const currentFilter = activeFilterBtn ? activeFilterBtn.dataset.severity : 'all';
    
    // Render the table with the fresh data and current filter
    renderAlerts(currentFilter);
    
  } catch (error) {
    console.error("[Orion] Failed to fetch live alerts:", error);
    const tbody = document.getElementById('alertsTableBody');
    if (tbody && liveAlertsData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#ff4444;">Connection to ORION Engine lost.</td></tr>`;
    }
  }
}

function renderAlerts(filter) {
  const tbody = document.getElementById('alertsTableBody');
  if (!tbody) return;

  // Filter the data (ignoring case to match "Critical" with "critical")
  const filtered = filter === 'all' 
    ? liveAlertsData 
    : liveAlertsData.filter(a => a.severity.toLowerCase() === filter.toLowerCase());

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">No alerts match this filter.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(alert => {
    // 1. Clean the timestamp (remove microseconds)
    const timeClean = alert.timestamp ? alert.timestamp.split('.')[0] : 'Unknown Time';
    
    // 2. Format the CSS class (e.g., 'Critical' -> 'critical')
    const sevLower = alert.severity ? alert.severity.toLowerCase() : 'low';
    
    // 3. Default status to 'open' since it isn't tracked in the DB yet
    const status = 'open';

    return `
      <tr>
        <td class="cell-timestamp">${timeClean}</td>
        <td class="cell-ip">${alert.source_ip}</td>
        <td>${alert.type}</td>
        <td><span class="severity-badge severity-badge--${sevLower}">${alert.severity}</span></td>
        <td>
          <span class="status-badge">
            <span class="status-badge__dot status-badge__dot--${status}"></span>
            ${status.charAt(0).toUpperCase() + status.slice(1)}
          </span>
        </td>
      </tr>
    `;
  }).join('');
}

export function initAlerts() {
  // 1. Fetch real data immediately when the component loads
  fetchLiveAlerts();

  // 2. Setup filter button listeners
  const filterBtns = document.querySelectorAll('.filter-btn');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('filter-btn--active'));
      btn.classList.add('filter-btn--active');
      renderAlerts(btn.dataset.severity);
    });
  });

  // 3. Auto-refresh the alerts every 3 seconds! 
  // (This makes your dashboard automatically update as the sniffer catches new threats)
  if (!window.orionPollInterval) {
    window.orionPollInterval = setInterval(fetchLiveAlerts, 3000);
  }
}