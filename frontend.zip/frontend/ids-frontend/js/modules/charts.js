/**
 * Charts Module - ORION INTEGRATED
 * Connects Chart.js visualizations to the real Python backend.
 */

// Helper to process SQLite alerts into Chart.js friendly format
function processAlertsForCharts(alerts) {
    const labels = [];
    const critical = [], high = [], medium = [], low = [];
    
    // Create hourly buckets for the last 12 hours
    const buckets = {};
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
        const d = new Date(now - i * 3600000);
        const label = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        labels.push(label);
        buckets[label] = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    }

    // Sort alerts into buckets
    alerts.forEach(alert => {
        const alertTime = new Date(alert.timestamp);
        const label = alertTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        // Find the closest bucket (simple match for this project)
        const bucketLabel = labels.find(l => l.split(':')[0] === label.split(':')[0]);
        if (bucketLabel && buckets[bucketLabel]) {
            const sev = alert.severity.charAt(0).toUpperCase() + alert.severity.slice(1).toLowerCase();
            if (buckets[bucketLabel][sev] !== undefined) {
                buckets[bucketLabel][sev]++;
            }
        }
    });

    labels.forEach(l => {
        critical.push(buckets[l].Critical);
        high.push(buckets[l].High);
        medium.push(buckets[l].Medium);
        low.push(buckets[l].Low);
    });

    return { labels, critical, high, medium, low };
}

async function createThreatChart(alerts) {
    const ctx = document.getElementById('threatCanvas');
    if (!ctx) return null;

    const data = processAlertsForCharts(alerts);

    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [
                { label: 'Critical', data: data.critical, backgroundColor: 'rgba(239,95,95,0.75)', borderRadius: 2 },
                { label: 'High', data: data.high, backgroundColor: 'rgba(240,145,95,0.7)', borderRadius: 2 },
                { label: 'Medium', data: data.medium, backgroundColor: 'rgba(240,197,65,0.6)', borderRadius: 2 },
                { label: 'Low', data: data.low, backgroundColor: 'rgba(107,184,255,0.5)', borderRadius: 2 },
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: true, position: 'top', align: 'end' }
            },
            scales: {
                x: { stacked: true, grid: { display: false } },
                y: { stacked: true, grid: { color: 'rgba(35,39,47,0.5)' } }
            }
        }
    });
}

// Keeping the Traffic Chart mostly aesthetic as the DB only logs threats, not total traffic
function createTrafficChart() {
    const ctx = document.getElementById('trafficCanvas');
    if (!ctx) return null;
    // ... (Keep your original createTrafficChart logic here for visual background noise)
}

export async function initCharts() {
    if (typeof Chart === 'undefined') return;

    try {
        const response = await fetch('/api/alerts');
        const alerts = await response.json();

        createTrafficChart(); // For the background "pulse"
        createThreatChart(alerts); // The real data from Python

    } catch (err) {
        console.error("[Orion] Chart data fetch failed:", err);
    }

    // Tab switching logic remains the same
    document.querySelectorAll('.chart-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const parent = tab.closest('.chart-card__controls');
            parent.querySelectorAll('.chart-tab').forEach(t => t.classList.remove('chart-tab--active'));
            tab.classList.add('chart-tab--active');
        });
    });
}