/**
 * Router Module - Optimized & Fixed
 */
import { initCounters } from './counters.js';
import { initAlerts } from './alerts.js';
import { initCharts } from './charts.js';
import { initNetworkMap } from './network-map.js';
import { initThreatRadar } from './threat-radar.js';
import { initLogStream } from './log-stream.js';
import { initSecurityGauge } from './security-gauge.js';

const PAGE_CONFIG = {
  dashboard: {
    components: [
      'components/stats.html',
      'components/charts.html',
      'components/visualizations.html',
      'components/alerts.html',
    ],
    init: async () => {
      // We make this async to ensure elements are ready
      await initCounters();
      waitForChart(initCharts);
      initNetworkMap();
      initThreatRadar();
      initLogStream();
      initSecurityGauge();
      initAlerts();
    },
    title: 'Dashboard',
    subtitle: 'Real-time network monitoring and threat intelligence',
  },
  // ... (keep other config the same)
};

let currentPage = null;
let cleanupFns = [];

// FIXED: Improved Chart.js waiter
function waitForChart(fn) {
  if (window.Chart) {
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.color = '#8b8f9a';
    fn();
  } else {
    setTimeout(() => waitForChart(fn), 100);
  }
}

async function loadPageContent(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    
    // ERROR CHECK: If the fetched HTML contains JS export statements, 
    // it means the file is "dirty" and will leak code to the UI.
    if (text.includes('export function') || text.includes('import {')) {
        console.error(`[Orion] Script leak detected in ${url}. Clean your HTML file!`);
    }
    return text;
  } catch (err) {
    return `<div class="page-error">Failed to load content: ${err.message}</div>`;
  }
}

export async function navigateTo(page) {
  if (page === currentPage) return;
  const config = PAGE_CONFIG[page];
  if (!config) return;

  const mainContent = document.getElementById('mainContent');
  if (!mainContent) return;

  // 1. Cleanup old state
  cleanupFns.forEach(fn => { if (typeof fn === 'function') fn(); });
  cleanupFns = [];

  // 2. Build Header first (Safe update)
  const headerHTML = `
    <div class="main__header">
      <div>
        <h1 class="main__title">${config.title}</h1>
        <p class="main__subtitle">${config.subtitle}</p>
      </div>
      <div class="main__actions">
        <span class="last-updated" id="lastUpdated">Updated just now</span>
        <button class="btn btn--outline" id="refreshBtn">Refresh</button>
      </div>
    </div>
    <div id="pageComponents"></div> 
  `;
  mainContent.innerHTML = headerHTML;
  const componentContainer = document.getElementById('pageComponents');

  // 3. Load Components Sequentially
  if (config.components) {
    for (const url of config.components) {
      const html = await loadPageContent(url);
      componentContainer.insertAdjacentHTML('beforeend', html);
    }
  } else if (config.page) {
    const html = await loadPageContent(config.page);
    componentContainer.insertAdjacentHTML('beforeend', html);
  }

  // 4. Initialize Modules ONLY after DOM is fully injected
  if (config.init) {
    config.init();
  }

  // 5. Setup UI state
  const refreshBtn = document.getElementById('refreshBtn');
  if (refreshBtn) {
    refreshBtn.onclick = () => {
        currentPage = null; // Reset so navigateTo forces a reload
        navigateTo(page);
    };
  }

  currentPage = page;
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('nav-item--active', item.dataset.page === page);
  });
}